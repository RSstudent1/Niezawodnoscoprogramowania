﻿
namespace Koszyk;

public record Produkt(int Id, string Nazwa, double cena);

public interface IDbService //interfejs posiada dwie metody zwracany bool wymagany produkt i jego id
{
    bool ZapiszProduktWKoszyku(Produkt prod);
    bool UsunProduktZKoszyka(int prodId);
}

public class KoszykSklepowy
{
    private IDbService _dbService; //klasa w konstruktorze przyjmuje obiekt klasy implementujacej interfejs IDbService odpowiadajacej za dodawanie i usuwanie przedmiotow z koszyka
    public KoszykSklepowy(IDbService dbService)
    {
        _dbService = dbService;
    }

    public bool DodajProdukt(Produkt? produkt)//klasa shoppingcart ma dwie metody ktora jezeli posiada id i produkt dodaje do koszyka
    {
        if (produkt == null)
            return false;
        if (produkt.Id == 0)
            return false;
        _dbService.ZapiszProduktWKoszyku(produkt);
        return true;
    }

    public bool UsunProdukt(int? id)
    {
        if (id == null)
            return false;
        if (id == 0)
            return false;
        _dbService.UsunProduktZKoszyka(Convert.ToInt32(id));
        return true;
    }
}