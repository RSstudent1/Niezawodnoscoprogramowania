﻿using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using Koszyk;

namespace KoszykTest
{
    public class KoszykSklepowyTest
    {
        public readonly Mock<IDbService> _dbServiceMock = new();
//inicjalizacja mock obiektu
        [Fact]
        public void DodajProdukt_Sukces() //testujemy metode addproduct
        {
            var koszykSklepowy = new KoszykSklepowy(_dbServiceMock.Object);//przekazanie mock obiektu 
            //po wywolaniu metody dla konkretnych parametrow ma byc zwrocony dodanie do koszyka
            var produkt = new Produkt(1, "shoes", 150);
            var result = koszykSklepowy.DodajProdukt(produkt);

            Assert.True(result);
            _dbServiceMock.Verify(x => x.ZapiszProduktWKoszyku(It.IsAny<Produkt>()), Times.Once);
        }

        [Fact]
        public void BladDodaniaProduktuPrzezNiepoprawneDane()
        {
            var koszykSklepowy = new KoszykSklepowy(_dbServiceMock.Object);

            var result = koszykSklepowy.DodajProdukt(null);

            Assert.False(result);
            _dbServiceMock.Verify(x => x.ZapiszProduktWKoszyku(It.IsAny<Produkt>()), Times.Never);
        }

        [Fact]
        public void UsunProdukt_Sukces()
        {
            var koszykSklepowy = new KoszykSklepowy(_dbServiceMock.Object);

            var produkt = new Produkt(1, "shoes", 150);
            var result = koszykSklepowy.DodajProdukt(produkt);
            var deleteResult = koszykSklepowy.UsunProdukt(produkt.Id);

            Assert.True(deleteResult);
            _dbServiceMock.Verify(x => x.ZapiszProduktWKoszyku(It.IsAny<Produkt>()), Times.Once);
        }
    }
}