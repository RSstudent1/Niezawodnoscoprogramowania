﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sortowanie_babelkowe.UnitTests
{
    [TestFixture]

    public class Sortowany_ciagTests
    {
        [Test]
        public void ListaKonstruktora_PosortowanaLista()
        {
            //ARRANGE
            var cyfry = new List<int> { 1, 22, 145, 3, 4, 20, 65, 11, 18, 1042, 5 };
            //ACT
            var sortowaneWarosci = new SortowanyCiag(cyfry);
            var skompletowanyString = sortowaneWarosci.ToString();


            //ASSERT
            var spodziewanyPosortowanyString = "1,3,4,5,11,18,20,22,65,145,1042";
            Assert.AreEqual(spodziewanyPosortowanyString, skompletowanyString);
        }
    }
}
