﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sortowanie_babelkowe
{
    public class Program
    {
        static void Main(string[] args)
        {
            var cyfry = new List<int> { 1, 22, 145, 3, 4, 20, 65, 11, 18, 1042, 5};
            Console.WriteLine(cyfry);

            var posortowanyCiag = new SortowanyCiag(cyfry);
            Console.WriteLine(posortowanyCiag);
            Console.ReadKey();
        }
    }
}
