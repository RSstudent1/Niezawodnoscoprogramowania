﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sortowanie_babelkowe
{
    public class SortowanyCiag
    { 
            private List<int> dane;


            public SortowanyCiag(List<int> dane)
            {
                this.dane = dane.ToList(); // "clone"
                sortowanieBabelkowe();
            }

            public SortowanyCiag(int[] dane)
            {
                this.dane = dane.ToList();
                sortowanieBabelkowe();
            }

            public void sortowanieBabelkowe()
            {
                for (var i = 0; i < dane.Count; i++)
                {
                    for (var j = 0; j < dane.Count - 1; j++)
                    {
                        if (dane[j] > dane[j + 1])
                        {
                            var tmp = dane[j];
                            dane[j] = dane[j + 1];
                            dane[j + 1] = tmp;
                        }
                    }
                }
            }



        public override string ToString()
            {
                return string.Join(",", dane);
            }
        }
    }

    

